document.addEventListener("DOMContentLoaded", function () {
    const themeToggleBtn = document.querySelector(".theme-toggle");
    const body = document.body;

    // Function to toggle dark mode
    themeToggleBtn.addEventListener("click", () => {
        body.classList.toggle("dark-mode");
        if (body.classList.contains("dark-mode")) {
            themeToggleBtn.innerHTML = "🌞";
        } else {
            themeToggleBtn.innerHTML = "🌙";
        }
    });

    // Typing effect
    const typingText = document.querySelector(".typing-text");
    const text = "Aspiring Web Developer";
    let index = 0;

    function typeText() {
        if (index < text.length) {
            typingText.textContent += text.charAt(index);
            index++;
            setTimeout(typeText, 150);
        }
    }

    typeText();
});
